import React,{Component}from 'react'
import {Link} from 'react-router'
export default class my extends Component{
    render(){
        return(
            <div>
               <h1 className='nothing'>还没有保存草稿</h1>
            </div>
        )
    }
}