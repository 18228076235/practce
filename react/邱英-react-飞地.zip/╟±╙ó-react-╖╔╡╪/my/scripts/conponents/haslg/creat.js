import React,{Component}from 'react'
import {Link} from 'react-router'
export default class my extends Component{
    render(){
        return(
            <div>
                <div className='nothing'>
                    <h1>还没有写过文章</h1>
                    <h2>现在就去写一篇</h2>
                </div> 
            </div>
        )
    }
}