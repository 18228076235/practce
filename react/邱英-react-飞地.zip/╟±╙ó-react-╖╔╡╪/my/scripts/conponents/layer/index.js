import layer from '../../../libs/layer_mobile/layer'

var laye=function(content){  
    layer.open({
        content: content
        ,style: 'background-color:#2524249c; color:#fff; border:none;padding:0px 0px;width:20%;padding-right: 30px;' //自定风格
        ,time: 2
      })
}

export default laye